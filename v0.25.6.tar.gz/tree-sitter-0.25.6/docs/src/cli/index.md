# CLI Overview

Let's go over all of the functionality of the `tree-sitter` command line interface.
Once you feel that you have enough of a grasp on the CLI, you can move onto the grammar authoring section to learn more about writing your own parser.
